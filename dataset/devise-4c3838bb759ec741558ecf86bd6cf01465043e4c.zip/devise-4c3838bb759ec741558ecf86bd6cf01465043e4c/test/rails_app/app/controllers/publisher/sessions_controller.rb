class Publisher::SessionsController < ApplicationController
end
