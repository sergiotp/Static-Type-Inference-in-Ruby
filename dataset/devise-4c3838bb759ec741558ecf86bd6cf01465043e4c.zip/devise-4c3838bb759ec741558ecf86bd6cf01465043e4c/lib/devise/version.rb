module Devise
  VERSION = "4.2.0".freeze
end
