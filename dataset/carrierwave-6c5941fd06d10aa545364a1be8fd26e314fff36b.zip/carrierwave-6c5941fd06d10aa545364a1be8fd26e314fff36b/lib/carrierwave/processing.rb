require "carrierwave/processing/rmagick"
require "carrierwave/processing/mini_magick"
