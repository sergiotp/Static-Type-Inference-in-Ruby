require 'carrierwave/utilities/uri'

module CarrierWave
  module Utilities
  end
end
