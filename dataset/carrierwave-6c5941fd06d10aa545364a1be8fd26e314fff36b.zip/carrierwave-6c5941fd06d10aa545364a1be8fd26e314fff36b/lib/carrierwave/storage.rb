require "carrierwave/storage/abstract"
require "carrierwave/storage/file"
