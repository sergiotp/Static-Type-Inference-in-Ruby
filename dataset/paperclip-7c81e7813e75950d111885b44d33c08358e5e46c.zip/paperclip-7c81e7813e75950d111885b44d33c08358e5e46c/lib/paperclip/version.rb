module Paperclip
  unless defined?(Paperclip::VERSION)
    VERSION = "5.1.0".freeze
  end
end
