require "paperclip/storage/filesystem"
require "paperclip/storage/fog"
require "paperclip/storage/s3"
