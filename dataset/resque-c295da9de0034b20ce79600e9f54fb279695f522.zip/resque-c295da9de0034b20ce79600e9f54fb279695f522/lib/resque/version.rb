module Resque
  Version = VERSION = '1.27.0'
end
