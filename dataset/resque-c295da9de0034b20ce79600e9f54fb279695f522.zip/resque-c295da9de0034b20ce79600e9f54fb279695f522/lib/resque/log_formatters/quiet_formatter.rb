module Resque
  class QuietFormatter
    def call(serverity, datetime, progname, msg)
      ""
    end
  end
end
