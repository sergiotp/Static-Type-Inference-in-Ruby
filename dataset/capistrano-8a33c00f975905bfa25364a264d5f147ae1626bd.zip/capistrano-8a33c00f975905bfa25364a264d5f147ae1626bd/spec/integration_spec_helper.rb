require "spec_helper"
require "support/test_app"
require "support/matchers"

include TestApp
