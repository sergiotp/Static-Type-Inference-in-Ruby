load File.expand_path("../tasks/console.rake", __FILE__)
