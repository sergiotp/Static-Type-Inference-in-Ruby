module Capistrano
  VERSION = "3.5.0".freeze
end
