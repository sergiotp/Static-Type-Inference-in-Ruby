module Grape
  class API
    module Helpers
      include Grape::DSL::Helpers::BaseHelper
    end
  end
end
