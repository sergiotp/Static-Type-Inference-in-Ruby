module Grape
  # The current version of Grape.
  VERSION = '0.19.2'.freeze
end
