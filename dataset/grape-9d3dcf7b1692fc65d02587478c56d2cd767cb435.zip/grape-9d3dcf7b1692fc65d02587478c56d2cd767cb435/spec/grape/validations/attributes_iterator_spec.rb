require 'spec_helper'

describe Grape::Validations::AttributesIterator do
end
