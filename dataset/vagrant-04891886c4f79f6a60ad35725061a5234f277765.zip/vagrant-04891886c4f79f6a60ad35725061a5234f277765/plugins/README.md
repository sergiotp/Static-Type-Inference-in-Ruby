# Vagrant Core Plugins

These are plugins that ship with Vagrant. Vagrant core uses its own
plugin system to power a lot of the core pieces that ship with Vagrant.
Each plugin will have its own README which explains its specific role.
