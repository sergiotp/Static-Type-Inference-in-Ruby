# frozen_string_literal: true
module Sidekiq
  VERSION = "4.2.9"
end
