Ruby version:
Sidekiq / Pro / Enterprise version(s):

If relevant, please include your initializer and any error message with the full backtrace.
